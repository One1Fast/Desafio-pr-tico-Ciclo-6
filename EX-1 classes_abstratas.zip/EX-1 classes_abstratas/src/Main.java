public class Main {
    public static void main(String[] args) {
        FormaGeometrica circulo = new Circulo("Azul", 5.0);
        FormaGeometrica retangulo = new Retangulo("Vermelho", 4.0, 3.0);

        circulo.desenhar();
        System.out.println("Área do círculo: " + circulo.calcularArea());
        System.out.println("Cor do círculo: " + circulo.getCor());

        retangulo.desenhar();
        System.out.println("Área do retângulo: " + retangulo.calcularArea());
        System.out.println("Cor do retângulo: " + retangulo.getCor());
    }
}
